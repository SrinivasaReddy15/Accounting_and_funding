package com.apex.accountFunding.service;


import com.apex.accountFunding.entity.Account;
import com.apex.accountFunding.entity.FundingIssue;
import com.apex.accountFunding.entity.Transaction;
import com.apex.accountFunding.entity.Wallet;
import com.apex.accountFunding.enums.*;
import com.apex.accountFunding.exception.AccountDetailsNotFoundException;
import com.apex.accountFunding.exception.InsufficientBalanceInAccount;
import com.apex.accountFunding.repository.AccountRepository;
import com.apex.accountFunding.repository.FundingIssueRepo;
import com.apex.accountFunding.repository.TransactionRepo;
import com.apex.accountFunding.repository.WalletRepository;
import com.apex.accountFunding.util.ReferenceIdGenerator;
import com.apex.accountFunding.util.ResponseStructure;
import org.springframework.http.HttpStatus;
import org.springframework.http.ReactiveHttpInputMessage;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.security.auth.login.AccountNotFoundException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class WalletService {
    public WalletService(WalletRepository walletRepository, TransactionRepo transactionRepo,AccountRepository accountRepository, FundingIssueRepo fundingIssueRepo, FundingIssueService fundingIssueService) {
        this.walletRepository = walletRepository;
        this.transactionRepo = transactionRepo;
        this.fundingIssueRepo = fundingIssueRepo;
        this.fundingIssueService = fundingIssueService;
        this.accountRepository = accountRepository;
    }
    private final WalletRepository walletRepository;

    private final TransactionRepo transactionRepo;

    private final FundingIssueRepo fundingIssueRepo;

    private final FundingIssueService fundingIssueService;

    private final AccountRepository accountRepository;

    public Wallet createWallet(Long accountId) {
       Optional<Account> account = accountRepository.findById(accountId);
        if(account.isPresent()) {
            Wallet wallet = new Wallet();
            wallet.setAccount(account.get());
            wallet.setCreatedAt(LocalDateTime.now());
            wallet.setUpdatedAt(LocalDateTime.now());
            wallet.setStatus(WalletStatus.ACTIVE);
            wallet.setBalance(0.0);
            return walletRepository.save(wallet);
        }else{
            throw  new AccountDetailsNotFoundException("Account Not Found");
        }
    }

    public Optional<Wallet> getWalletById(Long walletId) {
        return walletRepository.findById(walletId);
    }

    public Wallet updateWallet(Wallet wallet) {
        wallet.setUpdatedAt(LocalDateTime.now());
        return walletRepository.save(wallet);
    }

    public void deleteWallet(Long walletId) {
        walletRepository.deleteById(walletId);
    }

    public List<Wallet> getAllWallets() {
        return walletRepository.findAll();
    }

    public List<Wallet> getWalletsByAccountId(Long accountId) {
        return walletRepository.findByAccount_AccountId(accountId);
    }

    public ResponseEntity<ResponseStructure<Wallet>> fundWallet(Long walletId, Double amount, FundingMethod method) {
        Wallet wallet = walletRepository.findById(walletId)
                .orElseThrow(() -> new RuntimeException("Wallet not found"));
           //---Get Account Balance---
            Double balanceAmount = wallet.getAccount().getBalance();
            //---If Account Balance Is Greater Than Amount Withdraw, Then Fund Wallet
            if(balanceAmount > amount) {
                wallet.getAccount().setBalance(balanceAmount - amount);
                wallet.setBalance(wallet.getBalance() + amount);
                walletRepository.save(wallet);
                //---Create Transaction Object---
                String refId = ReferenceIdGenerator.generateTransactionReference(walletId,method);
                Transaction transaction = new Transaction();
                transaction.setWallet(wallet);
                transaction.setAmount(amount);
                transaction.setReferenceId(refId);
                transaction.setType(TransactionType.CREDIT);
                transaction.setMethodType(method);
                transaction.setStatus(TransactionStatus.SUCCESS);
                transaction.setTransactionTime(LocalDateTime.now());
                transactionRepo.save(transaction);

                ResponseStructure<Wallet> responseStructure = new ResponseStructure<>();
                responseStructure.setMessage("Transaction SuccessFull");
                responseStructure.setData(wallet);
                responseStructure.setStatusCode(HttpStatus.OK.value());
                return new ResponseEntity<ResponseStructure<Wallet>>(responseStructure,HttpStatus.OK);
            }else{
                fundingIssueService.createFundingIssue(null,"Insufficient Balance in account while funding wallet");
                ResponseStructure<Wallet> responseStructure = new ResponseStructure<>();
                responseStructure.setMessage("Funding failed: Insufficient Balance");
                responseStructure.setData(wallet); // still return wallet details
                responseStructure.setStatusCode(HttpStatus.BAD_REQUEST.value());
                return new ResponseEntity<>(responseStructure, HttpStatus.BAD_REQUEST);
            }


            // ---- Log Failure Transaction ----
            /*Transaction tx = new Transaction();
            tx.setWallet(wallet);
            tx.setAmount(amount);
            tx.setType(TransactionType.CREDIT);
            tx.setMethodType(method);
            tx.setStatus(TransactionStatus.FAILED);
            tx.setTransactionTime(LocalDateTime.now());
            transactionRepo.save(tx);

            // ---- Create Funding Issue ----
            fundingIssueService.createFundingIssue(tx.getTransactionId(),"fund transaction not success");
            FundingIssue issue = new FundingIssue();
            issue.setTransaction(tx);
            issue.setIssueDescription("Failed to fund wallet: " + ex.getMessage());
            issue.setIssueStatus(FundingIssueStatus.OPEN);
            issue.setCreatedAt(LocalDateTime.now());
            issue.setUpdatedAt(LocalDateTime.now());
            // optionally assign to a ClientServiceAgent later
            fundingIssueRepo.save(issue);

            throw new RuntimeException("Funding wallet failed", ex);*/
        }



    public Wallet deductFromWallet(Long walletId, Double amount) {
        Wallet wallet = walletRepository.findById(walletId)
                .orElseThrow(() -> new RuntimeException("Wallet not found"));

        if (wallet.getBalance() < amount) {
            throw new RuntimeException("Insufficient balance");
        }
        wallet.setBalance(wallet.getBalance() - amount);
        // optionally log Transaction
        return walletRepository.save(wallet);
    }

    public Wallet freezeWallet(Long walletId) {
        Wallet wallet = walletRepository.findById(walletId)
                .orElseThrow(() -> new RuntimeException("Wallet not found"));

        wallet.setStatus(WalletStatus.FROZEN);
        return walletRepository.save(wallet);
    }

    public Wallet unfreezeWallet(Long walletId) {
        Wallet wallet = walletRepository.findById(walletId)
                .orElseThrow(() -> new RuntimeException("Wallet not found"));

        wallet.setStatus(WalletStatus.ACTIVE);
        return walletRepository.save(wallet);
    }

    public Double checkBalance(Long walletId) {
        Wallet wallet = walletRepository.findById(walletId)
                .orElseThrow(() -> new RuntimeException("Wallet not found"));
        return wallet.getBalance();
    }
}
