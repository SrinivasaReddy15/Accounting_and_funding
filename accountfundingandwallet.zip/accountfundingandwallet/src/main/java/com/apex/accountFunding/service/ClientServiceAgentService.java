package com.apex.accountFunding.service;

import com.apex.accountFunding.entity.ClientServiceAgent;
import com.apex.accountFunding.exception.AgentNotFoundException;
import com.apex.accountFunding.repository.ClientServiceAgentRepo;
import com.apex.accountFunding.util.ResponseStructure;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ClientServiceAgentService {
    @Autowired
    private ClientServiceAgentRepo clientServiceAgentRepo;

    public ResponseEntity<ResponseStructure<ClientServiceAgent>> createClientServiceAgent(ClientServiceAgent clientServiceAgent){
        ResponseStructure<ClientServiceAgent> responseStructure = new ResponseStructure<>();
        responseStructure.setStatusCode(HttpStatus.CREATED.value());
        responseStructure.setMessage("ClientService Agent Created");
        responseStructure.setData(clientServiceAgentRepo.save(clientServiceAgent));
        return new ResponseEntity<ResponseStructure<ClientServiceAgent>>(responseStructure,HttpStatus.CREATED);
    }

    public ResponseEntity<ResponseStructure<ClientServiceAgent>> getAgentById(Long agentId){
        ResponseStructure<ClientServiceAgent> responseStructure = new ResponseStructure<>();
        Optional<ClientServiceAgent> optionalClientServiceAgent = clientServiceAgentRepo.findById(agentId);
        if(optionalClientServiceAgent.isPresent()) {
            responseStructure.setStatusCode(HttpStatus.FOUND.value());
            responseStructure.setMessage("Agent Found");
            responseStructure.setData(optionalClientServiceAgent.get());
            return new ResponseEntity<ResponseStructure<ClientServiceAgent>>(responseStructure,HttpStatus.FOUND);
        }else{
            throw new AgentNotFoundException("Agent Not Found");
        }
    }


}
