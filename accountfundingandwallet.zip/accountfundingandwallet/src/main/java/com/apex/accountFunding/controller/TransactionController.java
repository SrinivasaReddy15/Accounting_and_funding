package com.apex.accountFunding.controller;

import com.apex.accountFunding.entity.Transaction;
import com.apex.accountFunding.enums.TransactionStatus;
import com.apex.accountFunding.enums.TransactionType;
import com.apex.accountFunding.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping

public class TransactionController {
    @Autowired
    private TransactionService transactionService;


    @GetMapping("/wallet/{walletId}")
    public ResponseEntity<Page<Transaction>> getWalletTransactionsByType(
            @PathVariable Long walletId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false)TransactionType type, @RequestParam(required = false)TransactionStatus status) {
        if(type==null && status==null)
        {Page<Transaction> transactions = transactionService.findByWalletIdOrderByTransactionTimeDesc(page, size,walletId);
            return ResponseEntity.ok(transactions);}
        else if (type==null) {
            Page<Transaction> transactions = transactionService.findByWalletIdAndStatusOrderByTransactionTimeDesc(page, size,walletId,status);
            return ResponseEntity.ok(transactions);
        }
        else{
            Page<Transaction> transactions = transactionService.findByWalletIdAndTypeOrderByTransactionTimeDesc(page, size,walletId,type);
            return ResponseEntity.ok(transactions);
        }
    }

}

