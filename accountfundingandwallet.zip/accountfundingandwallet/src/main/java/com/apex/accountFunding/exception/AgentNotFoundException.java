package com.apex.accountFunding.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class AgentNotFoundException extends RuntimeException {
    private String message;

}
