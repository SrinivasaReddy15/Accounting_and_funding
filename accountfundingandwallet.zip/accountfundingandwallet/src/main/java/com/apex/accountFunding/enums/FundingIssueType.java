package com.apex.accountFunding.enums;

public enum FundingIssueType {
    PAYMENT_TIMEOUT,
    DUPLICATE_TRANSACTION,
    REFUND_PENDING,
    SETTLEMENT_DELAY,
    FRAUD_SUSPECTED,
    AMOUNT_MISMATCH,
    RECONCILIATION_ERROR,
    PAYMENT_FAILED,
    WEBHOOK_FAILED,
    RECORD_MISSING
}
