package com.apex.accountFunding.util;

import com.apex.accountFunding.enums.FundingIssueType;

public class RequiresAgent {
    public boolean requiresAgent(FundingIssueType type) {
        return switch (type) {
            case PAYMENT_TIMEOUT,
                 DUPLICATE_TRANSACTION,
                 REFUND_PENDING,
                 SETTLEMENT_DELAY,
                 FRAUD_SUSPECTED,
                 AMOUNT_MISMATCH,
                 RECONCILIATION_ERROR -> true;
            default -> false; // PAYMENT_FAILED, WEBHOOK_FAILED, RECORD_MISSING
        };
    }
}
