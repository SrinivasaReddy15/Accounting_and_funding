package com.apex.accountFunding.repository;

import com.apex.accountFunding.entity.FundingIssue;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface FundingIssueRepo extends JpaRepository<FundingIssue,Long> {

    Optional<FundingIssue> findByTransactionTransactionId(Long transactionId);
    Optional<FundingIssue> findByAgentAgentId(Long agenId);
}
