package com.apex.accountFunding.enums;

public enum FundingIssueStatus {
    OPEN, IN_PROGRESS, RESOLVED, CLOSED
}
