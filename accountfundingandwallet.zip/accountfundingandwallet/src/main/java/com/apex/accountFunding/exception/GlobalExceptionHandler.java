package com.apex.accountFunding.exception;

import com.apex.accountFunding.util.ResponseStructure;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(TransactionIdNotFoundException.class)
    public ResponseEntity<ResponseStructure<String>> handleTransactionNotFoundException(TransactionIdNotFoundException transactionIdNotFoundException){
        ResponseStructure<String> responseStructure = new ResponseStructure<>();
        responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
        responseStructure.setMessage(transactionIdNotFoundException.getMessage());
        return new ResponseEntity<ResponseStructure<String>>(responseStructure,HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(FundingIssueNotFound.class)
    public ResponseEntity<ResponseStructure<String>> handleFundingIssueNotFoundException(FundingIssueNotFound fundingIssueNotFound){
        ResponseStructure<String> responseStructure = new ResponseStructure<>();
        responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
        responseStructure.setMessage(fundingIssueNotFound.getMessage());
        return new ResponseEntity<ResponseStructure<String>>(responseStructure,HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(AgentNotFoundException.class)
    public ResponseEntity<ResponseStructure<String>> handleAgentNotFoundException(AgentNotFoundException agentNotFoundException){
        ResponseStructure<String> responseStructure = new ResponseStructure<>();
        responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
        responseStructure.setMessage(agentNotFoundException.getMessage());
        return new ResponseEntity<ResponseStructure<String>>(responseStructure,HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(AccountDetailsNotFoundException.class)
    public ResponseEntity<ResponseStructure<String>> handleAccountDetailsNotFoundException(AccountDetailsNotFoundException accountDetailsNotFoundException){
        ResponseStructure<String> responseStructure = new ResponseStructure<>();
        responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
        responseStructure.setMessage(accountDetailsNotFoundException.getMessage());
        return new ResponseEntity<ResponseStructure<String>>(responseStructure,HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(InsufficientBalanceInAccount.class)
    public ResponseEntity<ResponseStructure<String>> handleInsufficientBalance(InsufficientBalanceInAccount insufficientBalanceInAccount){
        ResponseStructure<String> responseStructure = new ResponseStructure<>();
        responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
        responseStructure.setMessage(insufficientBalanceInAccount.getMessage());
        return new ResponseEntity<ResponseStructure<String>>(responseStructure,HttpStatus.NOT_FOUND);
    }
}
