package com.apex.accountFunding.enums;

public enum WalletStatus {
    ACTIVE, FROZEN, CLOSED
}
