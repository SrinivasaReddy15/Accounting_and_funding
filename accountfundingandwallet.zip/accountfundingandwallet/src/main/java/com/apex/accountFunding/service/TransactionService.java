package com.apex.accountFunding.service;

import com.apex.accountFunding.entity.Transaction;
import com.apex.accountFunding.enums.TransactionStatus;
import com.apex.accountFunding.enums.TransactionType;
import com.apex.accountFunding.repository.TransactionRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class TransactionService {
    @Autowired
    TransactionRepo transactionRepo;

    public Page<Transaction> findByWalletIdOrderByTransactionTimeDesc(int page, int size, Long walletId)
    {
        Pageable pageable= PageRequest.of(page,size, Sort.by("transactionTime").descending());
        return transactionRepo.findByWalletIdOrderByTransactionTimeDesc(pageable,walletId);
    }
    public Page<Transaction>findByWalletIdAndStatusOrderByTransactionTimeDesc(int page, int size, Long walletId, TransactionStatus status)
    {
        Pageable pageable= PageRequest.of(page,size, Sort.by("transactionTime").descending());
        return transactionRepo.findByWalletIdAndStatusOrderByTransactionTimeDesc(walletId,status,pageable);

    }
    public Page<Transaction>findByWalletIdAndTypeOrderByTransactionTimeDesc(int page, int size, Long walletId, TransactionType type)
    {
        Pageable pageable= PageRequest.of(page,size, Sort.by("transactionTime").descending());
        return transactionRepo.findByWalletIdAndTypeOrderByTransactionTimeDesc(walletId,type,pageable);

    }

}
