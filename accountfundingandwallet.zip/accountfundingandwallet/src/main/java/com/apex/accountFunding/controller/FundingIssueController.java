package com.apex.accountFunding.controller;

import com.apex.accountFunding.entity.FundingIssue;
import com.apex.accountFunding.service.FundingIssueService;
import com.apex.accountFunding.util.ResponseStructure;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/fundingIssue")
public class FundingIssueController {

    @Autowired
    private FundingIssueService fundingIssueService;

    @PostMapping("/createFundingIssue")
    public ResponseEntity<ResponseStructure<FundingIssue>> createFundingIssue(@RequestParam Long transactionId, @RequestParam String issueDescription){
        return fundingIssueService.createFundingIssue(transactionId,issueDescription);
    }

    @GetMapping("/getFundingIssueById")
    public ResponseEntity<ResponseStructure<FundingIssue>> getFundingIssueById(@RequestParam Long fundingIssueId){
        return fundingIssueService.getFundingIssueById(fundingIssueId);
    }

    @GetMapping("/getFundingIssueByTransactionId")
    public ResponseEntity<ResponseStructure<FundingIssue>> getFundingIssueByTransactionId(@RequestParam Long transactionId){
        return fundingIssueService.getFundingIssueByTransactionId(transactionId);
    }

    @GetMapping("/getFundingIssueAgentId")
    public ResponseEntity<ResponseStructure<FundingIssue>> getFundingIssueByAgentId(@RequestParam Long agentId){
        return fundingIssueService.getFundingIssueByAgent(agentId);
    }






}
