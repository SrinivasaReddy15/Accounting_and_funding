package com.apex.accountFunding.enums;

public enum FundingMethod {
    BANK_TRANSFER, CARD , UPI
}
