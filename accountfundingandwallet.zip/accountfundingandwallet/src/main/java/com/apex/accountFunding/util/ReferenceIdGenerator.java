package com.apex.accountFunding.util;

import com.apex.accountFunding.enums.FundingMethod;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class ReferenceIdGenerator {

    public static String generateTransactionReference(Long walletId, FundingMethod method) {

        String timestamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());


        String randomStr = getRandomAlphaNumeric(6);


        return String.format("%s-%s-%s-%s-%s", "TXT", timestamp, walletId, method, randomStr);
    }

    private static String getRandomAlphaNumeric(int length) {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        StringBuilder sb = new StringBuilder();
        Random random = new Random();

        for (int i = 0; i < length; i++) {
            sb.append(chars.charAt(random.nextInt(chars.length())));
        }

        return sb.toString();
    }



}
