package com.apex.accountFunding.repository;

import com.apex.accountFunding.entity.Transaction;
import com.apex.accountFunding.enums.TransactionStatus;
import com.apex.accountFunding.enums.TransactionType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TransactionRepo extends JpaRepository<Transaction,Long> {
    Page<Transaction> findByWalletIdOrderByTransactionTimeDesc(Pageable pageable, Long walletId);
    Page<Transaction> findByWalletIdAndStatusOrderByTransactionTimeDesc(
            Long walletId,
            TransactionStatus status,
            Pageable pageable
    );
    Page<Transaction> findByWalletIdAndTypeOrderByTransactionTimeDesc(
            Long walletId,
            TransactionType type,
            Pageable pageable
    );
}
