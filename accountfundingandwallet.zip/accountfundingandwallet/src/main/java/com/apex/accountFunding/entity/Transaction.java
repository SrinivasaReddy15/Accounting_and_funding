package com.apex.accountFunding.entity;

import com.apex.accountFunding.enums.FundingMethod;
import com.apex.accountFunding.enums.TransactionStatus;
import com.apex.accountFunding.enums.TransactionType;
import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
@Entity
@Getter
@Setter
public class Transaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long transactionId;
    @ManyToOne
    @JoinColumn(name = "walletId")
    @JsonBackReference
    private Wallet wallet;
    private Double amount;
    private String referenceId;
    private TransactionType type;
    private FundingMethod methodType;
    private TransactionStatus status;
    private LocalDateTime transactionTime;

}

