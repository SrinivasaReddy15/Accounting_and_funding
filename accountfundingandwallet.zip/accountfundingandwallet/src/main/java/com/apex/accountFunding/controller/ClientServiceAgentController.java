package com.apex.accountFunding.controller;

import com.apex.accountFunding.entity.ClientServiceAgent;
import com.apex.accountFunding.service.ClientServiceAgentService;
import com.apex.accountFunding.util.ResponseStructure;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/agent")
public class ClientServiceAgentController {

    @Autowired
    private ClientServiceAgentService clientServiceAgentService;

    @PostMapping("/createAgent")
    public ResponseEntity<ResponseStructure<ClientServiceAgent>> createAgent(ClientServiceAgent clientServiceAgent){
        return clientServiceAgentService.createClientServiceAgent(clientServiceAgent);
    }

    @GetMapping("/getAgentById")
    public ResponseEntity<ResponseStructure<ClientServiceAgent>> getAgentById(Long agentId){
        return clientServiceAgentService.getAgentById(agentId);
    }



}
