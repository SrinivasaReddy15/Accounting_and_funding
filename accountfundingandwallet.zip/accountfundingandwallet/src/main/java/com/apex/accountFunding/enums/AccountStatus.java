package com.apex.accountFunding.enums;

public enum AccountStatus {
    ACTIVE, INACTIVE, CLOSED
}
