package com.apex.accountFunding.enums;

public enum TransactionStatus {
    PENDING, SUCCESS, FAILED
}
