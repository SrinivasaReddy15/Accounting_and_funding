package com.apex.accountFunding.controller;

import com.apex.accountFunding.entity.Wallet;
import com.apex.accountFunding.enums.FundingMethod;
import com.apex.accountFunding.service.WalletService;
import com.apex.accountFunding.util.ResponseStructure;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/wallets")
public class WalletController {
    private final WalletService walletService;

    public WalletController(WalletService walletService) {
        this.walletService = walletService;
    }

    @PostMapping
    public ResponseEntity<Wallet> createWallet(@RequestParam  Long accountId) {
        Wallet createdWallet = walletService.createWallet(accountId);
        return ResponseEntity.ok(createdWallet);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Wallet> getWalletById(@PathVariable("id") Long walletId) {
        return walletService.getWalletById(walletId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<Wallet> updateWallet(@PathVariable("id") Long walletId, @RequestBody Wallet wallet) {
        return walletService.getWalletById(walletId).map(existingWallet -> {
            wallet.setWalletId(walletId);
            Wallet updatedWallet = walletService.updateWallet(wallet);
            return ResponseEntity.ok(updatedWallet);
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteWallet(@PathVariable("id") Long walletId) {
        if (walletService.getWalletById(walletId).isPresent()) {
            walletService.deleteWallet(walletId);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping
    public ResponseEntity<List<Wallet>> getAllWallets() {
        return ResponseEntity.ok(walletService.getAllWallets());
    }

    @GetMapping("/account/{accountId}")
    public ResponseEntity<List<Wallet>> getWalletsByAccountId(@PathVariable Long accountId) {
        return ResponseEntity.ok(walletService.getWalletsByAccountId(accountId));
    }

    @PostMapping("/{walletId}/fund")
    public ResponseEntity<ResponseStructure<Wallet>> fundWallet(
            @PathVariable Long walletId,
            @RequestParam Double amount,
            @RequestParam FundingMethod method) {
        return walletService.fundWallet(walletId, amount, method);
    }

}
