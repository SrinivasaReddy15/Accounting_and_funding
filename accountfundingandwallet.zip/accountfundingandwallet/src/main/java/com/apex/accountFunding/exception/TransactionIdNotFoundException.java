package com.apex.accountFunding.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter
@Setter
@SuppressWarnings("")
public class TransactionIdNotFoundException extends RuntimeException {

    private String message;

}
