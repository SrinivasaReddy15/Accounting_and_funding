package com.apex.accountFunding.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class InsufficientBalanceInAccount extends RuntimeException {
    private String message;
}
