package com.apex.accountFunding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountFundingApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountFundingApplication.class, args);
	}

}
