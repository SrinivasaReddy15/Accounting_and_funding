package com.apex.accountFunding.entity;

import com.apex.accountFunding.enums.FundingIssueStatus;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
@Entity
@Getter
@Setter
public class FundingIssue {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long issueId;
    @OneToOne
    private  Transaction transaction;
    @ManyToOne
    private ClientServiceAgent agent;
    private String issueDescription;
    private FundingIssueStatus issueStatus;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
