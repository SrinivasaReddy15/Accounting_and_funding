package com.apex.accountFunding.enums;

public enum TransactionType {
    FUNDING,WITHDRAWAL,TRANSFER, CREDIT
}
