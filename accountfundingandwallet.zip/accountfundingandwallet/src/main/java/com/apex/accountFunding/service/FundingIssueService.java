package com.apex.accountFunding.service;

import com.apex.accountFunding.entity.FundingIssue;
import com.apex.accountFunding.entity.Transaction;
import com.apex.accountFunding.enums.FundingIssueStatus;
import com.apex.accountFunding.exception.FundingIssueNotFound;
import com.apex.accountFunding.repository.FundingIssueRepo;
import com.apex.accountFunding.repository.TransactionRepo;
import com.apex.accountFunding.util.ResponseStructure;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class FundingIssueService {
    @Autowired
    private FundingIssueRepo fundingIssueRepo;
    @Autowired
    private TransactionRepo transactionRepo;

    public ResponseEntity<ResponseStructure<FundingIssue>> createFundingIssue(Long transactionId, String issueDescription) {

        ResponseStructure<FundingIssue> responseStructure = new ResponseStructure<>();

        responseStructure.setStatusCode(HttpStatus.CREATED.value());
        responseStructure.setMessage("Funding Issue created for transactionId " + transactionId);
        FundingIssue fundingIssue = new FundingIssue();
        fundingIssue.setIssueDescription(issueDescription);
        if (transactionId != null) {
            Optional<Transaction> optionalTransaction = transactionRepo.findById(transactionId);
            fundingIssue.setTransaction(optionalTransaction.get());
            fundingIssue.setIssueStatus(FundingIssueStatus.OPEN);
        } else {
            fundingIssue.setTransaction(null);
            fundingIssue.setIssueStatus(FundingIssueStatus.CLOSED);
        }
            fundingIssue.setCreatedAt(LocalDateTime.now());
            responseStructure.setData(fundingIssueRepo.save(fundingIssue));
            return new ResponseEntity<ResponseStructure<FundingIssue>>(responseStructure, HttpStatus.CREATED);
    }

    public ResponseEntity<ResponseStructure<FundingIssue>> getFundingIssueById(Long fundingIssueId){
        Optional<FundingIssue> optionalFundingIssue = fundingIssueRepo.findById(fundingIssueId);
        if(optionalFundingIssue.isPresent()){
            ResponseStructure<FundingIssue> responseStructure = new ResponseStructure<>();
            responseStructure.setStatusCode(HttpStatus.FOUND.value());
            responseStructure.setMessage("Funding Issue Found");
            responseStructure.setData(optionalFundingIssue.get());
            return new ResponseEntity<ResponseStructure<FundingIssue>>(responseStructure,HttpStatus.FOUND);
        }else{
            throw new FundingIssueNotFound("Funding Issue Not Found");
        }
    }

    public ResponseEntity<ResponseStructure<FundingIssue>> getFundingIssueByTransactionId(Long transactionId)
    {
        Optional<FundingIssue> optionalFundingIssue = fundingIssueRepo.findByTransactionTransactionId(transactionId);
        if(optionalFundingIssue.isPresent()){
            ResponseStructure<FundingIssue> responseStructure = new ResponseStructure<>();
            responseStructure.setStatusCode(HttpStatus.FOUND.value());
            responseStructure.setMessage("Funding Issue Found");
            responseStructure.setData(optionalFundingIssue.get());
            return new ResponseEntity<ResponseStructure<FundingIssue>>(responseStructure,HttpStatus.FOUND);
        }else{
            throw new FundingIssueNotFound("Funding Issue Not Found");
        }
    }
    public ResponseEntity<ResponseStructure<FundingIssue>> getFundingIssueByAgent(Long agentId)
    {
        Optional<FundingIssue> optionalFundingIssue = fundingIssueRepo.findByAgentAgentId(agentId);
        if(optionalFundingIssue.isPresent()){
            ResponseStructure<FundingIssue> responseStructure = new ResponseStructure<>();
            responseStructure.setStatusCode(HttpStatus.FOUND.value());
            responseStructure.setMessage("Funding Issue Found");
            responseStructure.setData(optionalFundingIssue.get());
            return new ResponseEntity<ResponseStructure<FundingIssue>>(responseStructure,HttpStatus.FOUND);
        }else{
            throw new FundingIssueNotFound("Funding Issue Not Found");
        }
    }

    public ResponseEntity<ResponseStructure<FundingIssue>> deleteFundingIssue(Long fundingIssueId) {
        Optional<FundingIssue> optionalFundingIssue = fundingIssueRepo.findById(fundingIssueId);
        if(optionalFundingIssue.isPresent()){
            ResponseStructure<FundingIssue> responseStructure = new ResponseStructure<>();
            responseStructure.setStatusCode(HttpStatus.OK.value());
            responseStructure.setMessage("Funding Issue Deleted");
            fundingIssueRepo.deleteById(fundingIssueId);
            responseStructure.setData(optionalFundingIssue.get());
            return new ResponseEntity<ResponseStructure<FundingIssue>>(responseStructure,HttpStatus.FOUND);
        }else{
            throw new FundingIssueNotFound("Funding Issue Not Found");
        }
    }

    public ResponseEntity<ResponseStructure<FundingIssue>> assignAgent(Long fundingIssueId){
        return null;
    }

    public ResponseEntity<ResponseStructure<FundingIssue>> escalateIssue(Long fundingIssueId){
        return null;
    }
}
