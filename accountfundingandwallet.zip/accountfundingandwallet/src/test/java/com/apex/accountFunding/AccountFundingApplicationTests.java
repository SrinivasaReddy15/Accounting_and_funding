package com.apex.accountFunding;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountFundingApplicationTests {

	@Test
	void contextLoads() {
	}

}
